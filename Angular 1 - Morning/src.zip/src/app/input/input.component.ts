import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss']
})
export class InputComponent implements OnInit {
  data : Array<any> = [];
  text : string ;
  constructor() { 
    this.text = "";
  }
  typed(event : any)
  {
    this.text=event.target.value;
    this.data.push({text : this.text, date : new Date()});
  } 

  ngOnInit(): void {
  }
}
