package com.mockito.MockitoPrime;

public interface PrimeChecker {
	 public boolean isPrime(int n);
}
