package com.example.au.couchbasedemo.model;

import java.util.List;


import org.springframework.data.annotation.Id;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.Field;

import com.sun.istack.NotNull;

@Document
public class Movie {
	
	@Id
	String id;
	
	@NotNull
	@Field
	String moviename;
	
	@NotNull
	@Field
	List<String> city;
		
	public String getId() {
		return id;
	}	
	
	public void setId(String id){
		this.id=id;
	}
	
	public String getMovieName() {
		return moviename;
	}
	
	public void setMovieName(String moviename) {
		this.moviename=moviename;
	}
	
	public List<String> getCity() {
		return city;
	}
	
	public void setCity(List<String> city) {
		this.city=city;
	}
	

	public Movie(String id, String moviename, List<String> city) {
		super();
		this.id = id;
		this.moviename = moviename;
		this.city = city;
	}
	

}
