package com.example.au.couchbasedemo.model;

import org.springframework.data.annotation.Id;

import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.Field;

import com.sun.istack.NotNull;

@Document
public class Football {
	
	@Id
	String id;
	
	@NotNull
	@Field
	String player;
	
	@NotNull
	@Field
	int goals;
	
	public String getId(){
		return id;
	}
	
	public void setId(String id){
		this.id=id;
	}
	
	public String getPlayer(){
		return player;
	}
	
	public void setPlayer(String player){
		this.player=player;
	}
	

	public int getGoals(){
		return goals;
	}
	
	public void setGoals(int goals){
		this.goals=goals;
	}
	
	public Football(String id, String player,int goals)
	{
		this.id=id;
		this.player=player;
		this.goals=goals;
	}
}


