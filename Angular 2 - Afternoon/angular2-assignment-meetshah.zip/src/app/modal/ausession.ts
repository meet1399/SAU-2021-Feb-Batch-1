export interface AuSession {
    session: string;
    instructor: string;
    desc: string;
}